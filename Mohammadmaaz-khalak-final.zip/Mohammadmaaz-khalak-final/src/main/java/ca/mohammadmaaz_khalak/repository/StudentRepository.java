package ca.mohammadmaaz_khalak.repository;

import ca.mohammadmaaz_khalak.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentRepository {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    public List<Student> findAll() {
        String sql = "SELECT * FROM students";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Student.class));
    }

    public Student findById(Long id) {
        String sql = "SELECT * FROM students WHERE id = :id";
        MapSqlParameterSource params = new MapSqlParameterSource("id", id);
        return jdbcTemplate.queryForObject(sql, params, new BeanPropertyRowMapper<>(Student.class));
    }

    public void save(Student student) {
        String sql = "INSERT INTO students (number, name) VALUES (:number, :name)";
        MapSqlParameterSource params = new MapSqlParameterSource()
                .addValue("number", student.getNumber())
                .addValue("name", student.getName());
        jdbcTemplate.update(sql, params);
    }

    // Additional methods for courses can be added here
}
