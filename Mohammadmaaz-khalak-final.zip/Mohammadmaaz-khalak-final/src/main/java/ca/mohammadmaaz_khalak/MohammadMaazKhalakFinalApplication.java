package ca.mohammadmaaz_khalak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MohammadMaazKhalakFinalApplication {
    public static void main(String[] args) {
        SpringApplication.run(MohammadMaazKhalakFinalApplication.class, args);
    }
}
