INSERT INTO students (id, number, name) VALUES (1, 1001, 'John Doe');
INSERT INTO students (id, number, name) VALUES (2, 1002, 'Jane Smith');
INSERT INTO students (id, number, name) VALUES (3, 1003, 'Robert Brown');

INSERT INTO courses (id, name, grade, studentId) VALUES (1, 'Mathematics', 85, 1);
INSERT INTO courses (id, name, grade, studentId) VALUES (2, 'Science', 92, 1);
INSERT INTO courses (id, name, grade, studentId) VALUES (3, 'Literature', 88, 2);
INSERT INTO courses (id, name, grade, studentId) VALUES (4, 'Art', 78, 3);
INSERT INTO courses (id, name, grade, studentId) VALUES (5, 'History', 91, 3);
