package ca.mohammadmaaz_khalak.controller;

import ca.mohammadmaaz_khalak.model.Student;
import ca.mohammadmaaz_khalak.service.StudentService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(StudentController.class)
public class StudentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private StudentService studentService;

    @Test
    public void testListStudents() throws Exception {
        when(studentService.getAllStudents()).thenReturn(Collections.singletonList(new Student()));

        mockMvc.perform(get("/students"))
                .andExpect(status().isOk());

        verify(studentService, times(1)).getAllStudents();
    }
}
