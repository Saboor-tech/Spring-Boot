package ca.mohammadmaaz_khalak.repository;

import ca.mohammadmaaz_khalak.model.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.JdbcTest;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@JdbcTest
public class StudentRepositoryTest {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Test
    public void testFindAll() {
        StudentRepository studentRepository = new StudentRepository(jdbcTemplate);
        List<Student> students = studentRepository.findAll();
        assertEquals(0, students.size()); // Adjust the expected size based on your test setup
    }
}
